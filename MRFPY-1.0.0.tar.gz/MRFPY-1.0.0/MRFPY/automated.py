#----------------------------------------------------------------------------------------------------------------------#
# Arrays + DataFrame -> Objects and Operations
#----------------------------------------------------------------------------------------------------------------------#
import numpy as np
import pandas as pd

#----------------------------------------------------------------------------------------------------------------------#
# Parallel computation
#----------------------------------------------------------------------------------------------------------------------#
import multiprocessing
from functools import partial

import itertools

#----------------------------------------------------------------------------------------------------------------------#
# Wavelet Forecasting Framework
#----------------------------------------------------------------------------------------------------------------------#
from MRFPY.forecast import onestep, multistep


"""
Automated
Modellselektion an Hand bester one step forecast auf letztem Tag/letzter Woche/...
MS multi step letzter Tag/Woche/...

Zur Auswahl für die Modellselektion stehen alle Level oder nur eins?


Modellselektion MCMC Varian Scott
Modellselektion Warmstart für evolutionäre optimierung
"""

def create_models(UnivariateData, base = np.array([2, 3, 5, 7, 9])):
    lst_models = []
    len_data = len(UnivariateData)
    for b in base:
        for i in range(4):
            x = b ** (np.arange(i + 2) + 1)
            maxConLen = np.max(x) - 1  # Req. to construct decompositon
            tmpVAR = np.append(x, x[len(x) - 1])
            maxReqLen = np.max(np.ones(len(x) + 1) * 10 * tmpVAR)  # Req. to construct model
            startTraining = maxReqLen + maxConLen
            if (startTraining < len_data):
                lst_models.append(x)
                lst_models.append(np.append(x, x[len(x) - 1] + 2))
                # lst_models.append(np.append(x,x[len(x)-1]+3))
                # lst_models.append(np.append(x,x[len(x)-1]+5))
    #lst_models = [np.array([2,4]), np.array([3,6]),
    #              np.array([2,4,8]), np.array([3,6,12]),
    #              np.array([2,4,8,16]), np.array([3,6,12,24]),
    #              np.array([2,4,8,16,32]), np.array([3,6,12,24,48])]
    return lst_models


def eval_model(model, UnivariateData, MultivariateData=None, Method="r", MSRange = 3, NumMV=1,
               hidden_layer_sizes=8, activation="relu", solver="lbfgs", alpha=1e-5, n_estimators=100,
               criterion="mae",
               max_depth=3, loss="ls", learning_rate=0.1, subsample=0.9, random_state=0, strategy="mean",
               max_iter=5000,
               threshold=False, thresholdStrategy="hard", thresholdLambda=0.05):
    numCoefficients = len(model)
    Coeff = np.ones(numCoefficients+1) * 10
    Forecast, m = onestep(UnivariateData=UnivariateData[:-1], CoefficientCombination=Coeff,
                          Aggregation=model, Method=Method, MultivariateData=MultivariateData, NumMV=NumMV,
                          hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver=solver,
                          alpha=alpha, n_estimators=n_estimators,
                          criterion=criterion,
                          max_depth=max_depth, loss=loss, learning_rate=learning_rate, subsample=subsample,
                          random_state=random_state, strategy=strategy,
                          max_iter=max_iter,
                          threshold=threshold, thresholdStrategy=thresholdStrategy,
                          thresholdLambda=thresholdLambda)
    MAE = abs(Forecast-UnivariateData[-1])
    Parameters = Coeff
    return MAE, Parameters


def eval_all_models(all_models, UnivariateData, MultivariateData=None, Method="r", MSRange = 3, NumMV=1,
                    hidden_layer_sizes=8, activation="relu", solver="lbfgs", alpha=1e-5, n_estimators=100,
                    criterion="mae",
                    max_depth=3, loss="ls", learning_rate=0.1, subsample=0.9, random_state=0, strategy="mean",
                    max_iter=5000, Model=None,
                    threshold=False, thresholdStrategy="hard", thresholdLambda=0.05):
    NumModels = len(all_models)
    QMModels = np.zeros(NumModels)
    TmpParameters = list()
    # Loop through models
    for i in range(NumModels):
        tmp_model = all_models[i]
        QM, Parameters = eval_model(model=tmp_model, UnivariateData=UnivariateData,
                                    MultivariateData=MultivariateData, Method=Method,
                                    MSRange=MSRange, NumMV=NumMV,
                                    hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver=solver,
                                    alpha=alpha, n_estimators=n_estimators,
                                    criterion=criterion,
                                    max_depth=max_depth, loss=loss, learning_rate=learning_rate, subsample=subsample,
                                    random_state=random_state, strategy=strategy,
                                    max_iter=max_iter,
                                    threshold=threshold, thresholdStrategy=thresholdStrategy,
                                    thresholdLambda=thresholdLambda)
        # Save QM with model setting
        QMModels[i] = QM
        TmpParameters.append(Parameters)
    # Get best model
    BestModelIndex = np.argmin(QMModels)
    BestParameters = TmpParameters[BestModelIndex]
    BestModel = all_models[BestModelIndex]
    # Return best model
    return BestModel, BestParameters


def wavelet_forecast(UnivariateData,
                     Horizon=1, Method="r", MultivariateData=None, NumMV=1, MSRange=3,
                     hidden_layer_sizes=8, activation="relu", solver="lbfgs", alpha=1e-5, n_estimators=100,
                     criterion="mae",
                     max_depth=3, loss="ls", learning_rate=0.1, subsample=0.9, random_state=0, strategy="mean",
                     max_iter=5000, threshold=False, thresholdStrategy="hard", thresholdLambda=0.05):
    # Create models to investigate
    all_models = create_models(UnivariateData)
    # Evaluate best model and setting (parameters)
    BestModel, BestParameters = eval_all_models(all_models=all_models, UnivariateData=UnivariateData,
                                                MultivariateData=MultivariateData, Method=Method,
                                                MSRange=MSRange, NumMV=NumMV,
                                                hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver=solver,
                                                alpha=alpha, n_estimators=n_estimators,
                                                criterion=criterion,
                                                max_depth=max_depth, loss=loss, learning_rate=learning_rate, subsample=subsample,
                                                random_state=random_state, strategy=strategy,
                                                max_iter=max_iter,
                                                threshold=threshold, thresholdStrategy=thresholdStrategy,
                                                thresholdLambda=thresholdLambda)
    # Use best model setting and create one/multi-step forecast
    Forecast,m = multistep(UnivariateData, Horizon, BestParameters, BestModel, Method=Method,
                           MultivariateData=MultivariateData, NumMV=NumMV,
                           hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver=solver,
                           alpha=alpha, n_estimators=n_estimators,
                           criterion=criterion,
                           max_depth=max_depth, loss=loss, learning_rate=learning_rate, subsample=subsample,
                           random_state=random_state, strategy=strategy,
                           max_iter=max_iter,
                           threshold=threshold, thresholdStrategy=thresholdStrategy, thresholdLambda=thresholdLambda)
    return Forecast, BestModel, BestParameters


def rolling_wavelet_forecast(UnivariateData, Horizon=2, Window=2, Method="r",
                             MultivariateData=None, NumMV=1, MSRange=3,
                             hidden_layer_sizes=8, activation="relu", solver="lbfgs", alpha=1e-5, n_estimators=100,
                             criterion="mae",
                             max_depth=3, loss="ls", learning_rate=0.1, subsample=0.9, random_state=0, strategy="mean",
                             max_iter=5000, Threshold=False, ThresholdStrategy="hard", ThresholdLambda=0.05):
    intLen = len(UnivariateData)
    mat_error = np.zeros((Window, Horizon))
    mat_forecast = np.zeros((Window, Horizon))
    for i in range(Window):
        int_Index = intLen - Window - Horizon + i  # Current Forecast Position
        dfTrain = UnivariateData[0:(int_Index + 1)]
        dfTest = UnivariateData[(int_Index + 1):(int_Index + 1 + Horizon)]
        forecast, agg, par = wavelet_forecast(dfTrain,
                                    Horizon=Horizon, Method=Method, MultivariateData=MultivariateData, NumMV=NumMV,
                                    MSRange=MSRange,
                                    hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver=solver,
                                    alpha=alpha, n_estimators=n_estimators,
                                    criterion=criterion,
                                    max_depth=max_depth, loss=loss, learning_rate=learning_rate, subsample=subsample,
                                    random_state=random_state, strategy=strategy,
                                    max_iter=max_iter,
                                    threshold=Threshold, thresholdStrategy=ThresholdStrategy,
                                    thresholdLambda=ThresholdLambda)
        arr_Error = np.array(dfTest - forecast)
        mat_error[i] = arr_Error
        mat_forecast[i] = np.array(dfTest)
    return mat_error, mat_forecast



def eval_model_deprecated(model, UnivariateData, Horizon, MultivariateData=None, Method="r", MSRange = 3, NumMV=1,
               hidden_layer_sizes=8, activation="relu", solver="lbfgs", alpha=1e-5, n_estimators=100,
               criterion="mae",
               max_depth=3, loss="ls", learning_rate=0.1, subsample=0.9, random_state=0, strategy="mean",
               max_iter=5000,
               threshold=False, thresholdStrategy="hard", thresholdLambda=0.05):
    numCoefficients = len(model)
    x = np.arange(1, 2 + 1)
    AllCoefficientCombination = np.array(list(itertools.product(x, repeat=numCoefficients+1)))
    #Coeff = np.ones(numCoefficients) * 10
    numCoeffCombs = len(AllCoefficientCombination)
    GlobalMAE = np.zeros(numCoeffCombs)
    len_data = len(UnivariateData)
    for j in range(numCoeffCombs):
        CrossVal = np.zeros((MSRange, Horizon))
        currCoeffComb = np.array(AllCoefficientCombination[j])
        # Evaluation of the last 3-5 steps
        for i in range(1,MSRange+1):
            currData = UnivariateData[:-i-Horizon]
            MultiStep, m = multistep(UnivariateData=currData, Horizon=Horizon,
                                     CoefficientCombination=currCoeffComb,
                                     Aggregation=model, Method=Method, MultivariateData=MultivariateData, NumMV=NumMV,
                                     hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver=solver,
                                     alpha=alpha, n_estimators=n_estimators,
                                     criterion=criterion,
                                     max_depth=max_depth, loss=loss, learning_rate=learning_rate, subsample=subsample,
                                     random_state=random_state, strategy=strategy,
                                     max_iter=max_iter,
                                     threshold=threshold, thresholdStrategy=thresholdStrategy,
                                     thresholdLambda=thresholdLambda)
            TrueValues = UnivariateData[len_data-i-Horizon:len_data-i]
            CrossVal[i-1,:] = MultiStep-TrueValues
        MAE = abs(CrossVal).sum().sum()/(Horizon*MSRange)
        GlobalMAE[j] = MAE
    Index = np.argmin(GlobalMAE)
    MAE = np.min(GlobalMAE)
    Parameters = np.array(AllCoefficientCombination[Index])
    return MAE, Parameters


#
#
#
#
#
