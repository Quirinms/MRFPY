#----------------------------------------------------------------------------------------------------------------------#
# Author: Quirin Stier
# Date  : 20.05.2021
# Namings, Writer and Logging
#----------------------------------------------------------------------------------------------------------------------#

#----------------------------------------------------------------------------------------------------------------------#
# Arrays + DataFrame -> Objects and Operations
#----------------------------------------------------------------------------------------------------------------------#
import numpy as np
import pandas as pd
from datetime import date
import multiprocessing


def write_forecast_error(Error, Forecast, QM, DataName, DataType, ModelSelection, Type, Method,
                         Input, Sparse, SparseCoverage, numClusters, runningTime, OutDirectoryError="",
                         OutDirectoryForecast="", ErrorType="", Threshold=False, ThresholdStrategy="", ThresholdLambda=""):
    """
    Creates csv and txt => 2 files.
    Writes error to csv and information log to txt


    """
    # Add "/"-ending if necessary
    OutDirectoryError    = check_OutDirectory_ending(OutDirectoryError)
    OutDirectoryForecast = check_OutDirectory_ending(OutDirectoryForecast)

    # Process numerical values to strings which can be saved on disk
    Input           = process_Input(Input)

    # Use short names and abbreviations
    # Names for csv files containing error and forecast
    NameCSV    = get_string_name(Method=Method, DataType=DataType, Threshold=Threshold,
                                 ThresholdStrategy=ThresholdStrategy, Type=Type, Ending=".csv")

    # Get full names of abbreviations
    ModelSelection  = get_long_model_selection_name(ModelSelection)

    # Name for log txt containing important information about the forecast
    NameTXT = get_string_name(Method=Method, DataType=DataType, Threshold=Threshold,
                              ThresholdStrategy=ThresholdStrategy, Type=Type, Ending=".txt")

    if numClusters == "max":
        numCores = multiprocessing.cpu_count()
        numClusters = numCores - 1

    # Write log
    forecast_log(NameTXT=NameTXT, OutDirectory=OutDirectoryError, QM=QM, DataName=DataName, DataType=DataType,
                 ModelSelection=ModelSelection, Threshold=Threshold, ThresholdStrategy=ThresholdStrategy,
                 ThresholdLambda=ThresholdLambda, RFO=Type, Method=Method, Input=Input, Sparse=Sparse,
                 SparseCoverage=SparseCoverage, numClusters=numClusters, runningTime=runningTime, ErrorType=ErrorType)
    forecast_log(NameTXT=NameTXT, OutDirectory=OutDirectoryForecast, QM=QM, DataName=DataName, DataType=DataType,
                 ModelSelection=ModelSelection, Threshold=Threshold, ThresholdStrategy=ThresholdStrategy,
                 ThresholdLambda=ThresholdLambda, RFO=Type, Method=Method, Input=Input, Sparse=Sparse,
                 SparseCoverage=SparseCoverage, numClusters=numClusters, runningTime=runningTime, ErrorType=ErrorType)

    # Write Error
    # Build DataFrame, name columns after the forecasting horizon from 1 to h
    if type(Error) == np.ndarray:
        dfError = pd.DataFrame(Error)
        numCols = dfError.shape[1] + 1
        dfError.columns = np.arange(1, numCols)
        # Save to disk
        dfError.to_csv(OutDirectoryError + NameCSV, index=False)

    # Write Forecast
    # Build DataFrame, name columns after the forecasting horizon from 1 to h
    if type(Forecast) == np.ndarray:
        dfForecast = pd.DataFrame(Forecast)
        numCols    = dfForecast.shape[1] + 1
        dfForecast.columns = np.arange(1, numCols)
        # Save to disk
        dfForecast.to_csv(OutDirectoryForecast + NameCSV, index=False)
    return


def get_string_name(Method, DataType, Threshold, ThresholdStrategy, Type, Ending, File=""):
    today = date.today()
    if Threshold == True:
        Threshold = "Threshold_" + ThresholdStrategy
    else:
        Threshold = ""
    Name = str(today) + "_MRF_" + Method + "_"  + DataType + "_" + Threshold + "_" + Type + "_" + File + Ending
    return Name


def process_Input(Input):
    if type(Input) == np.ndarray:
        newInput = ""
        for i in range(len(Input)):
            newInput = newInput + str(int(Input[i]))
            if i < (len(Input) - 1):
                newInput = newInput + "_"
        Input = newInput
    return Input


def check_OutDirectory_ending(OutDirectory):
    if OutDirectory[-1:] != "!":
        OutDirectory = OutDirectory + "/"
    return OutDirectory


def get_long_model_selection_name(ModelSelection):
    if ModelSelection == "evopt":
        ModelSelection = "Evolutionary Optimization"
    return ModelSelection


def forecast_log(NameTXT, OutDirectory, QM, DataName, DataType, ModelSelection, Threshold, RFO, Method,
                 Input, Sparse, SparseCoverage, numClusters, runningTime, ErrorType, ThresholdStrategy, ThresholdLambda):
    # log every important information
    today = date.today()
    f = open(OutDirectory + NameTXT, "w")
    f.write("File written on             : " + str(today) + "\n")
    f.write("Dataset                     : " + DataName + "\n")
    f.write("Datatype                    : " + DataType + "\n")
    f.write("Model selection             : " + ModelSelection + "\n")

    if RFO == "Test":
        RFO = "Nonnested RFO/Performance computed on Test data"
    if RFO == "Eval":
        RFO = "Nested RFO/Performance computed on Evaluation data"

    f.write("Rolling Forecasting Origin  : " + RFO + "\n")

    f.write("Quality measure             : " + str(QM) + "\n")

    f.write("Method                      : " + Method + "\n")

    f.write("Input                       : " + Input + "\n")

    if Threshold == False:
        ThresholdStrategy = ""
        ThresholdLambda = ""
    f.write("Threshold                   : " + ThresholdStrategy + "\n")
    f.write("Threshold lambda            : " + str(ThresholdLambda) + "\n")

    if Sparse==True:
        Sparse = "Sparse"
    else:
        Sparse = "Nonsparse"
    f.write("Sparse                      : " + Sparse + "\n")
    f.write("SparseCoverage              : " + str(SparseCoverage) + "\n")

    f.write("Number of computing cores   : " + str(numClusters) + "\n")
    f.write("Run time model selection    : " + str(np.round(runningTime,2)) + "\n")

    f.write("Type of error               : " + ErrorType + "\n")
    f.close()
    return


#
#
#
#
#