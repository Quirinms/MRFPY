#----------------------------------------------------------------------------------------------------------------------#
# Author: Quirin Stier
#
# Assumption: Workflow for a forecasting project with predefined directory structure
# This structure can be named customly, here, only an example is given. It could be possible all the same, but this
# will create a mess and potentially more difficulties with the naming of files
# Data is in one of three directories: InDirectory = 00CollectedData/01RawData/02Transformed
#
# Number of Level
# Which coefficients -> Lagged Selection + Model Selection (with evopt)
# Threshold: Yes/No? Soft/Hard? Which lambda?
# Univariate/Multivariate
# If Multivariate: NumMV? Number of variables from multivariate data at each step
#
#----------------------------------------------------------------------------------------------------------------------#

import numpy as np
import pandas as pd
import time
from os import listdir
from datetime import date

# MD plot
#import md_plot
#import plotnine as p9

from MRFPY.modelSelection import model_selection
from MRFPY.forecastdata import write_forecast_error

def execute_forecast_computation(ErrorDirectory, ForecastDirectory,
                                 DataName,
                                 Aggregation, Horizon,
                                 TestLength, EvaluationLength,
                                 Method,
                                 CoefficientsMinimum, CoefficientsMaximum,
                                 UnivariateData, MultivariateData=None,
                                 ExecuteUnivariate=True, ExecuteMultivariate=False,
                                 Sparse=False, SparseCoverage=0.3,
                                 numClusters="max",
                                 QualityMeasure="MAE", Optimization="evopt",
                                 ThresholdLambda=0.05, Print=True):

    # Univariate Data
    if ExecuteUnivariate == True:
        #--------------------------------------------------------------------------------------------------------------#
        #
        #--------------------------------------------------------------------------------------------------------------#
        print("Model selection with evopt on univariate data with max clusters, no threshold")
        t = time.time()
        I, TE, TF, TQM, EE, EF, EQM = model_selection(UnivariateData=UnivariateData,
                                                      CoefficientsMinimum=CoefficientsMinimum,
                                                      CoefficientsMaximum=CoefficientsMaximum,
                                                      Aggregation=Aggregation, Horizon=Horizon,
                                                      TestLength=TestLength, EvaluationLength=EvaluationLength,
                                                      Method=Method,
                                                      MultivariateData=None,
                                                      Sparse=Sparse, SparseCoverage=SparseCoverage,
                                                      numClusters=numClusters,
                                                      QualityMeasure=QualityMeasure, Optimization=Optimization,
                                                      Threshold=False)
        print(len(TE))
        elapsed = time.time() - t
        if Print==True:
            write_forecast_error(Error=TE, Forecast=TF, QM=TQM, DataName=DataName, DataType="Univariate",
                                 ModelSelection=Optimization,
                                 Type="Test", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Test error", Threshold=False)
        if Print==True:
            write_forecast_error(Error=EE, Forecast=EF, QM=EQM, DataName=DataName, DataType="Univariate",
                                 ModelSelection=Optimization,
                                 Type="Eval", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Evaluation error", Threshold=False)

        #--------------------------------------------------------------------------------------------------------------#
        #
        #--------------------------------------------------------------------------------------------------------------#
        print("Model selection with evopt on univariate data with max clusters, non sparse, hard threshold, lambda = " + str(ThresholdLambda))
        I, TE, TF, TQM, EE, EF, EQM = model_selection(UnivariateData=UnivariateData,
                                                      CoefficientsMinimum=CoefficientsMinimum,
                                                      CoefficientsMaximum=CoefficientsMaximum,
                                                      Aggregation=Aggregation, Horizon=Horizon,
                                                      TestLength=TestLength, EvaluationLength=EvaluationLength,
                                                      Method=Method,
                                                      MultivariateData=None,
                                                      Sparse=Sparse, SparseCoverage=SparseCoverage,
                                                      numClusters=numClusters,
                                                      QualityMeasure=QualityMeasure, Optimization=Optimization,
                                                      Threshold=True,
                                                      ThresholdStrategy="hard", ThresholdLambda=ThresholdLambda)

        if Print==True:
            write_forecast_error(Error=TE, Forecast=TF, QM=TQM, DataName=DataName, DataType="Univariate",
                                 ModelSelection=Optimization,
                                 Type="Test", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Test error",
                                 Threshold=True, ThresholdStrategy="hard", ThresholdLambda=ThresholdLambda)
        if Print==True:
            write_forecast_error(Error=EE, Forecast=EF, QM=EQM, DataName=DataName, DataType="Univariate",
                                 ModelSelection=Optimization,
                                 Type="Eval", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Evaluation error",
                                 Threshold=True, ThresholdStrategy="hard", ThresholdLambda=ThresholdLambda)

        #--------------------------------------------------------------------------------------------------------------#
        #
        #--------------------------------------------------------------------------------------------------------------#
        print("Model selection with evopt on univariate data with max clusters, soft threshold, lambda = " + str(ThresholdLambda))
        I, TE, TF, TQM, EE, EF, EQM = model_selection(UnivariateData=UnivariateData,
                                                      CoefficientsMinimum=CoefficientsMinimum,
                                                      CoefficientsMaximum=CoefficientsMaximum,
                                                      Aggregation=Aggregation, Horizon=Horizon,
                                                      TestLength=TestLength, EvaluationLength=EvaluationLength,
                                                      Method=Method,
                                                      MultivariateData=None,
                                                      Sparse=Sparse, SparseCoverage=SparseCoverage,
                                                      numClusters=numClusters,
                                                      QualityMeasure=QualityMeasure, Optimization=Optimization,
                                                      Threshold=True,
                                                      ThresholdStrategy="soft", ThresholdLambda=ThresholdLambda)
        if Print==True:
            write_forecast_error(Error=TE, Forecast=TF, QM=TQM, DataName=DataName, DataType="Univariate",
                                 ModelSelection=Optimization,
                                 Type="Test", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Test error",
                                 Threshold=True, ThresholdStrategy="soft", ThresholdLambda=ThresholdLambda)
        if Print==True:
            write_forecast_error(Error=EE, Forecast=EF, QM=EQM, DataName=DataName, DataType="Univariate",
                                 ModelSelection=Optimization,
                                 Type="Eval", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Evaluation error",
                                 Threshold=True, ThresholdStrategy="soft", ThresholdLambda=ThresholdLambda)

        #--------------------------------------------------------------------------------------------------------------#
        #
        #--------------------------------------------------------------------------------------------------------------#

    # Multivariate Data
    if ExecuteMultivariate == True:
        print("Model selection with evopt on univariate data with max clusters, no threshold")
        t = time.time()
        I, TE, TF, TQM, EE, EF, EQM = model_selection(UnivariateData=UnivariateData,
                                                      CoefficientsMinimum=CoefficientsMinimum,
                                                      CoefficientsMaximum=CoefficientsMaximum,
                                                      Aggregation=Aggregation, Horizon=Horizon,
                                                      TestLength=TestLength, EvaluationLength=EvaluationLength,
                                                      Method=Method,
                                                      MultivariateData=MultivariateData, NumMV=1,
                                                      Sparse=Sparse, SparseCoverage=SparseCoverage,
                                                      numClusters=numClusters,
                                                      QualityMeasure=QualityMeasure, Optimization=Optimization,
                                                      Threshold=False)
        elapsed = time.time() - t
        if Print == True:
            write_forecast_error(Error=TE, Forecast=TF, QM=TQM, DataName=DataName, DataType="Multivariate",
                                 ModelSelection=Optimization,
                                 Type="Test", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Test error", Threshold=False)
        if Print == True:
            write_forecast_error(Error=EE, Forecast=EF, QM=EQM, DataName=DataName, DataType="Multivariate",
                                 ModelSelection=Optimization,
                                 Type="Eval", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Evaluation error", Threshold=False)

        #--------------------------------------------------------------------------------------------------------------#
        # Multivariate hard
        #--------------------------------------------------------------------------------------------------------------#
        print("Model selection with evopt on multivariate data with max clusters, hard threshold, lambda = " + str(ThresholdLambda))
        t = time.time()
        I, TE, TF, TQM, EE, EF, EQM = model_selection(UnivariateData=UnivariateData,
                                                      CoefficientsMinimum=CoefficientsMinimum,
                                                      CoefficientsMaximum=CoefficientsMaximum,
                                                      Aggregation=Aggregation, Horizon=Horizon,
                                                      TestLength=TestLength, EvaluationLength=EvaluationLength,
                                                      Method=Method,
                                                      MultivariateData=MultivariateData, NumMV=2,
                                                      Sparse=Sparse, SparseCoverage=SparseCoverage,
                                                      numClusters=numClusters,
                                                      QualityMeasure=QualityMeasure, Optimization=Optimization,
                                                      Threshold=True,
                                                      ThresholdStrategy="hard", ThresholdLambda=ThresholdLambda)
        elapsed = time.time() - t
        if Print == True:
            write_forecast_error(Error=TE, Forecast=TF, QM=TQM, DataName=DataName, DataType="Multivariate",
                                 ModelSelection=Optimization,
                                 Type="Test", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Test error",
                                 Threshold=True, ThresholdStrategy="hard", ThresholdLambda=ThresholdLambda)
        if Print == True:
            write_forecast_error(Error=EE, Forecast=EF, QM=EQM, DataName=DataName, DataType="Multivariate",
                                 ModelSelection=Optimization,
                                 Type="Eval", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Evaluation error",
                                 Threshold=True, ThresholdStrategy="hard", ThresholdLambda=ThresholdLambda)

        #--------------------------------------------------------------------------------------------------------------#
        # Multivariate soft
        #--------------------------------------------------------------------------------------------------------------#
        print("Model selection with evopt on multivariate data with max clusters, soft threshold, lambda = " + str(ThresholdLambda))
        t = time.time()
        I, TE, TF, TQM, EE, EF, EQM = model_selection(UnivariateData=UnivariateData,
                                                      CoefficientsMinimum=CoefficientsMinimum,
                                                      CoefficientsMaximum=CoefficientsMaximum,
                                                      Aggregation=Aggregation, Horizon=Horizon,
                                                      TestLength=TestLength, EvaluationLength=EvaluationLength,
                                                      Method=Method,
                                                      MultivariateData=MultivariateData, NumMV=1,
                                                      Sparse=Sparse, SparseCoverage=SparseCoverage,
                                                      numClusters=numClusters,
                                                      QualityMeasure=QualityMeasure, Optimization=Optimization,
                                                      Threshold=True,
                                                      ThresholdStrategy="soft", ThresholdLambda=ThresholdLambda)
        elapsed = time.time() - t
        if Print == True:
            write_forecast_error(Error=TE, Forecast=TF, QM=TQM, DataName=DataName, DataType="Multivariate",
                                 ModelSelection=Optimization,
                                 Type="Test", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Test error",
                                 Threshold=True, ThresholdStrategy="soft", ThresholdLambda=ThresholdLambda)
        if Print == True:
            write_forecast_error(Error=EE, Forecast=EF, QM=EQM, DataName=DataName, DataType="Multivariate",
                                 ModelSelection=Optimization,
                                 Type="Eval", Method=Method, Input=I, Sparse=Sparse, SparseCoverage=SparseCoverage,
                                 numClusters=numClusters, runningTime=elapsed,
                                 OutDirectoryError=ErrorDirectory, OutDirectoryForecast=ForecastDirectory,
                                 ErrorType="Evaluation error",
                                 Threshold=True, ThresholdStrategy="soft", ThresholdLambda=ThresholdLambda)

    return None


def execute_forecast_evaluation(ErrorDirectory, ForecastDirectory, MAEDirectory, QMDirectory):

    # Choose method with smallest error and give it the methods name => MRR, MRNN
    # Write your findings in a log file => date, input, method, threshold, thresholdLambda
    # MRFPY interna comparison MDplot?
    # Global comparison MDplot with all available methods!
    # => Prophet, MAPA, ...

    # All error files
    AllDirElements = listdir(ErrorDirectory)
    AllDirElements = [file for file in AllDirElements if file[-4:] == ".csv"]

    # Nested error files
    NestedErrors = [file for file in AllDirElements if "Nested" in file]
    dfMAE = get_all_MAE(NestedErrors)
    today = date.today()
    dfMAE.to_csv(str(today) + "Nested_MAE_Table.csv")

    # Nonnested error files
    NonnestedErrors = [file for file in AllDirElements if "Nonnested" in file]
    dfMAE = get_all_MAE(NonnestedErrors)
    today = date.today()
    dfMAE.to_csv(str(today) + "Nonnested_MAE_Table.csv")

    # MD plot for nested MAE horizon=1
    dfMAEH1 = pd.DataFrame()
    for ErrorFile in NestedErrors:
        Error = pd.read_csv(ErrorFile)
        MAE = np.abs(Error)
        dfMAEH1[ErrorFile[:-4]] = MAE.iloc[:, 0]
    today = date.today()
    mdplot = md_plot.MDplot(df_mase, Ordering='Alphabetical') + p9.theme_seaborn() + p9.xlab("") + p9.ylab("MAE")
    mdplot.save(str(today) + "_Nested_MAE_Horizon_1.png")

    # MD plot for nested MAE overall
    dfMAEH1 = pd.DataFrame()
    for ErrorFile in NestedErrors:
        Error = pd.read_csv(ErrorFile)
        MAE = np.abs(Error)
        dim1 = MAE.shape[0]
        dim2 = MAE.shape[1]
        dfMAEH1[ErrorFile[:-4]] = np.sum(np.sum(MAE))/(dim1 * dim2)
    today = date.today()
    mdplot = md_plot.MDplot(df_mase, Ordering='Alphabetical') + p9.theme_seaborn() + p9.xlab("") + p9.ylab("MAE")
    mdplot.save(str(today) + "_Nested_MAE_Horizon_1.png")


    """
    # Compute MAE
    for ErrorFile in AllDirElements:
        Error = pd.read_csv(ErrorFile)
        #dim1 = Error.shape[0]
        #dim2 = Error.shape[1]
        #MAE = np.sum(np.sum(np.abs(Error))) / (dim1*dim2)
        MAE = np.abs(Error)
        MAE.to_csv(MAEDirectory + ErrorFile)

    # Creat MD plots

    # Filter for Nested Rolling Forecasting Origins
    AllDirElements = listdir(ErrorDirectory)
    AllDirElements = [file for file in AllDirElements if file[-4:] == ".csv"]
    NestedMAEs     = [file for file in AllDirElements if "Nested" in file]

    # Create MDplots for Nested Rolling Forecasting Origins
    df_mase = pd.DataFrame()
    counter = 0
    min_MAE = 0
    for MAEFile in NestedMAEs:
        MAE = pd.read_csv(MAEFile)
        if counter == 0:
            min_MAE
        MAE = pd.read_csv(MAEFile)
        Horizon1 = MAE.iloc[:,0]

        counter = counter +

    today = date.today()
    mdplot = md_plot.MDplot(df_mase, Ordering='Alphabetical') + p9.theme_seaborn() + p9.xlab("") + p9.ylab("MASE")
    mdplot.save(str(today) + "_MASE_Reference_Horizon_1.png")
    # Compute MASE

    # Create MDplots

    # Create full forecast visualization
    # Prediction interval + model fit + true values + forecast
    """
    return


def get_all_MAE(ListErrorFiles):
    #numMAEs = len(ListFiles)
    info    = pd.read_csv(ListErrorFiles[0])
    Window  = info.shape[0]
    Horizon = info.shape[1]
    ColumnNames = ["Name"]
    for i in range(Horizon):
        ColumnNames.append("Horizon" + str(i))
    ColumnNames.append("Overall")
    dfAllMAE = pd.DataFrame(columns=ColumnNames)
    for ErrorFile in ListErrorFiles:
        Error = pd.read_csv(ErrorFile)
        MAE = np.abs(Error)
        dct = {"Name": ErrorFile[:-4]}
        for i in range(Horizon):
            dct.update({"Horizon" + str(i): np.sum(MAE.iloc[:,i])/Window})
        dct.update({"Overall": np.sum(np.sum(MAE))/(Window*Horizon)})
        dfAllMAE.append(dct, ignore_index=True)
    return dfAllMAE

