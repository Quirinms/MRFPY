#----------------------------------------------------------------------------------------------------------------------#
# Author: Quirin Stier
# Date: 07.05.2021
# Wavelet Forecasting Framework
# One-step and multi-step forecasts with wavelets
#----------------------------------------------------------------------------------------------------------------------#

#----------------------------------------------------------------------------------------------------------------------#
# Arrays + DataFrame -> Objects and Operations
#----------------------------------------------------------------------------------------------------------------------#
import numpy as np
import pandas as pd

#----------------------------------------------------------------------------------------------------------------------#
# Parallel computation
#----------------------------------------------------------------------------------------------------------------------#
#import multiprocessing
#from functools import partial

#----------------------------------------------------------------------------------------------------------------------#
# Wavelet Framework
#----------------------------------------------------------------------------------------------------------------------#
from MRFPY.wavelet import decomposition
from MRFPY.wavelet import prediction_scheme
from MRFPY.wavelet import training

#----------------------------------------------------------------------------------------------------------------------#
# Regression tools from scikit learn
#----------------------------------------------------------------------------------------------------------------------#
from sklearn.ensemble import AdaBoostRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor


"""
Modellselektion MCMC Varian Scott
Modellselektion Warmstart für evolutionäre optimierung
"""

def in_sample_forecast():

    return


#
#
#
#
#
