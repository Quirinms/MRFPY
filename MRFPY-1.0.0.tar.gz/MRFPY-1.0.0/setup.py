from setuptools import setup

setup(
    name="MRFPY",
    version="1.0.0",
    description="Multiresolution Time Series Forecasting",
    author="Quirin Stier",
    author_email="Quirin_Stier@gmx.de",
    packages=['MRFPY'],  #same as name
    install_requires=[], #external packages as dependencies
    include_package_data=True,
    package_data={"":["data"]}
)
